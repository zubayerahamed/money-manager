<div class="d-flex justify-content-between align-itmes-center">
    <div class="col-md-6 float-start text-start">
        <h5 class="mb-0">Current Balance : <?php echo e($totalBalance == null ? 0 : $totalBalance); ?> <?php echo e(auth()->user()->currency); ?></h5>
        <h5 class="mb-0 text-warning">Excluded Balance : <?php echo e($totalBalanceEx == null ? 0 : $totalBalanceEx); ?> <?php echo e(auth()->user()->currency); ?></h5>
    </div>

    <div class="col-md-6 float-end text-end d-flex align-itmes-center justify-content-end">
        <a href="<?php echo e(route('wallet.create')); ?>" class="btn btn-success btn-sm transaction-btn" data-title="<?php echo e(__('wallet.btn.create-wallet')); ?>">
            <i class="ph-plus"></i>
            <div class="d-none d-md-block ms-1"><?php echo e(__('wallet.btn.create-wallet')); ?></div>
        </a>
    </div>
</div>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/wallets/wallets-header.blade.php ENDPATH**/ ?>