<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageTitle' => ''.e(__('dream.page.title')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => ''.e(__('dream.page.title')).'']); ?>
    <!-- Content -->
    <div class="content">
        <div class="row">
            <div class="col-xl-12">

                <!-- Dreams Section -->
                <div class="card">

                    <div class="card-header">
                        <div class="col-md-6 float-start text-start">
                            <h5 class="mb-0"><?php echo e(__('dream.header.dreams')); ?></h5>
                        </div>

                        <div class="col-md-6 float-end text-end">
                            <a href="<?php echo e(route('dream.create')); ?>" class="btn btn-success btn-sm transaction-btn" data-title="<?php echo e(__('dream.btn.create-dream')); ?>" title="<?php echo e(__('dream.btn.create-dream')); ?>">
                                <i class="ph-plus"></i>
                                <div class="d-none d-md-block ms-1"><?php echo e(__('dream.btn.create-dream')); ?></div>
                            </a>
                        </div>
                    </div>

                    <div class="accordion accordion-flush dreams-accordion" id="accordion_flush">
                        <?php echo $__env->make('layouts.dreams.dreams-accordion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
                <!-- ./Dreams Section -->

            </div>
        </div>
    </div>
    <!-- ./Content -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/dreams.blade.php ENDPATH**/ ?>