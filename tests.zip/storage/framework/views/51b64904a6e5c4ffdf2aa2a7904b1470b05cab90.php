<div class="d-flex justify-content-between align-itmes-center">
    <div class="col-md-6 float-start text-start">
        <h5 class="mb-0"><?php echo e(__('income-source.header.income')); ?> : <?php echo e($totalIncome == null ? 0 : $totalIncome); ?> <?php echo e(auth()->user()->currency); ?></h5>
        <h5 class="mb-0 text-warning">Total loan : <?php echo e($totalLoan == null ? 0 : $totalLoan); ?> <?php echo e(auth()->user()->currency); ?></h5>
    </div>
    
    <div class="col-md-6 float-end text-end d-flex align-itmes-center justify-content-end">
        <a href="<?php echo e(route('income-source.create')); ?>" class="btn btn-success btn-sm transaction-btn" title="<?php echo e(__('income-source.btn.create-income-source')); ?>" data-title="<?php echo e(__('income-source.btn.create-income-source')); ?>">
            <i class="ph-plus"></i>
            <div class="d-none d-md-block ms-1"><?php echo e(__('income-source.btn.create-income-source')); ?></div>
        </a>
    </div>
</div><?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/income-sources/income-sources-header.blade.php ENDPATH**/ ?>