<div class="col-md-6 float-start text-start">
    <h5 class="mb-0"><?php echo e(__('expense-type.header.expense')); ?> : <?php echo e($totalExpense == null ? 0 : $totalExpense); ?> <?php echo e(auth()->user()->currency); ?></h5>
</div>

<div class="col-md-6 float-end text-end">
    <a href="<?php echo e(route('expense-type.create')); ?>" class="btn btn-success btn-sm transaction-btn" data-title="<?php echo e(__('expense-type.btn.create-expense-type')); ?>">
        <i class="ph-plus"></i>
        <div class="d-none d-md-block ms-1"><?php echo e(__('expense-type.btn.create-expense-type')); ?></div>
    </a>
</div>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/layouts/expense-types/expense-types-header.blade.php ENDPATH**/ ?>