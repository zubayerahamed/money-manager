<?php $__currentLoopData = $dreams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dream): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordion-item">

        <h2 class="accordion-header">
            <button class="accordion-button fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush_item<?php echo e($dream->id); ?>">
                <div class="d-flex align-items-center">

                    <div class="me-2">
                        <img class="img-fluid" src="<?php echo e($dream->image); ?>" width="80" height="80" alt="">
                    </div>

                    <div>
                        <div style="text-transform: uppercase; font-weight: bold;"><?php echo e($dream->name); ?></div>
                        <div class="text-muted fs-sm">
                            <p class="m-0"><?php echo e(__('dream.text.value')); ?> : <?php echo e($dream->amount_needed); ?> <?php echo e(auth()->user()->currency); ?></p>
                            <?php if($dream->amount_needed > 0 && $dream->wallet != null): ?>
                                <p class="m-0"><?php echo e(__('dream.text.achieved')); ?> : <?php echo e($dream->amount_needed <= $dream->wallet->currentBalance ? '' : $dream->wallet->currentBalance . auth()->user()->currency); ?> (<?php echo e($dream->amount_needed <= $dream->wallet->currentBalance ? '100%' : round((100 * $dream->wallet->currentBalance) / $dream->amount_needed, 2) . '%'); ?>)</p>
                            <?php endif; ?>
                            <p class="m-0"><?php echo e(__('dream.text.target')); ?> : <?php echo e($dream->target_year); ?></p>
                        </div>
                    </div>

                </div>
            </button>
        </h2>

        <div id="flush_item<?php echo e($dream->id); ?>" class="accordion-collapse collapse" data-bs-parent="#accordion_flush">
            <div class="accordion-body">
                <div class="col-md-12 text-center">

                    <?php if($dream->note != ''): ?>
                        <div class="col-md-12 text-center mb-2">
                            <span class="fw-semibold"><?php echo e($dream->note); ?></span>
                        </div>
                    <?php endif; ?>

                    <span class="badge border border-teal text-teal rounded-pill m-auto">
                        <input type="file" name="image" class="form-control avatar-image" id="<?php echo e($dream->id); ?>" accept="image/*">

                        <a href="<?php echo e(route('dream.image', $dream->id)); ?>" class="m-2 text-primary avatar-upload" title="<?php echo e(__('dream.btn.edit-image')); ?>">
                            <i class="fas fa-images"></i>
                        </a>

                        <a href="<?php echo e(route('dream.edit', $dream->id)); ?>" class="m-2 text-primary transaction-btn" data-title="<?php echo e(__('dream.btn.edit-dream')); ?>" title="<?php echo e(__('dream.btn.edit-dream')); ?>">
                            <i class="fas fa-edit"></i>
                        </a>

                        <form id="form-id<?php echo e($dream->id); ?>"
                              action="<?php echo e(route('dream.destroy', $dream->id)); ?>"
                              method="POST" style="display: inline-block;">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <a href="#" class="delete-btn text-danger m-2"
                               onclick="deleteData(this)"
                               data-form-id="<?php echo e('form-id' . $dream->id); ?>"
                               title="<?php echo e(__('dream.btn.delete-dream')); ?>">
                                <i class="fas fa-trash"></i>
                            </a>
                        </form>
                    </span>

                </div>
            </div>
        </div>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/dreams/dreams-accordion.blade.php ENDPATH**/ ?>