<?php if(count($thDetails) == 0): ?>
    <h2 class="text-center m-0">Transactions are not available</h2>
<?php endif; ?>
<?php $__currentLoopData = $thDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">

        <div class="card-header">
            <div class="col-md-10 float-start">
                <h5 class="mb-0"><?php echo e($key); ?></h5>
            </div>
            <div class="col-md-2 float-end text-end">
                <span style="color: red; font-weight: bold"><?php echo e($val['expense']); ?></span>
            </div>
        </div>

        <div class="accordion accordion-flush" id="accordion_flush_detail">
            <?php $__currentLoopData = $val['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">

                    <h2 class="accordion-header">
                        <button class="accordion-button fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush_item_detail_<?php echo e($trn->id); ?>">
                            <div class="row">
                                <div class="d-flex">

                                    <span class="text-danger"><b><?php echo e($trn->amount); ?> <?php echo e(auth()->user()->currency); ?></b> <?php echo e(__('transaction.details.expense.for')); ?> <b style="text-transform: uppercase;"><?php echo e($trn->subExpenseType->name); ?></b></span>
                                    <?php if($val['income'] == ''): ?>
                                        <span><?php echo '&nbsp; (' . $trn->transaction_date . ')'; ?></span>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </button>
                    </h2>


                    <div id="flush_item_detail_<?php echo e($trn->id); ?>" class="accordion-collapse collapse" data-bs-parent="#accordion_flush_detail">
                        <div class="accordion-body">

                            <div class="col-md-12 text-center">
                                <span class="badge border border-teal text-teal rounded-pill m-auto">
                                    <a href="<?php echo e(route('tracking.edit', $trn->tracking_history_id)); ?>" class="m-2 text-primary transaction-btn" title="Edit" data-title="<?php echo e(__('transaction.btn.edit-transaction')); ?>" title="<?php echo e(__('transaction.btn.edit-transaction')); ?>">
                                        <i class="far fa-edit"></i>
                                    </a>

                                    <form id="form-id<?php echo e($trn->id); ?>"
                                          action="<?php echo e(route('tracking.destroy', $trn->tracking_history_id)); ?>"
                                          method="POST" style="display: inline-block;">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <a href="#" class="delete-btn text-danger m-2"
                                           onclick="deleteData(this)"
                                           data-form-id="<?php echo e('form-id' . $trn->id); ?>"
                                           title="<?php echo e(__('transaction.btn.delete-transaction')); ?>">
                                            <i class="far fa-trash-alt"></i>
                                        </a>
                                    </form>
                                </span>
                            </div>

                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/sub-expense-types/transaction-detail-accordion.blade.php ENDPATH**/ ?>