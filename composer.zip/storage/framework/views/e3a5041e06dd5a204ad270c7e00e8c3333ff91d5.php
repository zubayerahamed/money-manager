<form id="transaction-form" action="<?php echo e($budget->id == null ? route('budget.store') : route('budget.update', $budget->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($budget->id != null): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <?php if($budget->id == null): ?>
        <?php if($expenseType->icon): ?>
            <i class="<?php echo e($expenseType->icon); ?> fa-2x" id="replacable-icon" style="padding: 10px; border: 1px solid #000; border-radius: 5px; margin-bottom: 10px;"></i>
        <?php endif; ?>

        <div class="row mb-3">
            <label class="form-label" for="expense_type"><?php echo e(__('budget.label.expense_type')); ?></label>
            <div class="form-group">
                <input type="hidden" name="expense_type" value="<?php echo e($expenseType->id); ?>" />
                <input type="hidden" name="month" value="<?php echo e($month); ?>" />
                <input type="hidden" name="year" value="<?php echo e($year); ?>" />
                <input type="text" class="form-control" id="expense_type" value="<?php echo e($expenseType->name); ?>" readonly>
            </div>
        </div>

        <div class="row mb-3">
            <label class="form-label" for="amount"><?php echo e(__('budget.label.amount')); ?></label>
            <div class="form-group">
                <input type="number" name="amount" id="amount" class="form-control" value="0.0" min="0" step="any" required>
            </div>
        </div>

        <div class="row mb-3">
            <label class="form-label" for="note"><?php echo e(__('budget.label.note')); ?></label>
            <div class="form-group">
                <textarea rows="3" cols="3" class="form-control" name="note" id="note"></textarea>
            </div>
        </div>
    <?php else: ?>
        <?php if($budget->expenseType->icon): ?>
            <i class="<?php echo e($budget->expenseType->icon); ?> fa-2x" id="replacable-icon" style="padding: 10px; border: 1px solid #000; border-radius: 5px; margin-bottom: 10px;"></i>
        <?php endif; ?>

        <div class="row mb-3">
            <label class="form-label" for="expense_type"><?php echo e(__('budget.label.expense_type')); ?></label>
            <div class="form-group">
                <input type="hidden" name="expense_type" value="<?php echo e($budget->expense_type); ?>" />
                <input type="text" class="form-control" id="expense_type" value="<?php echo e($budget->expenseType->name); ?>" readonly>
            </div>
        </div>

        <div class="row mb-3">
            <label class="form-label" for="amount"><?php echo e(__('budget.label.amount')); ?></label>
            <div class="form-group">
                <input type="number" name="amount" id="amount" class="form-control" value="<?php echo e(old('amount', $budget->amount)); ?>" min="0" step="any" required>
            </div>
        </div>

        <div class="row mb-3">
            <label class="form-label" for="note"><?php echo e(__('budget.label.note')); ?></label>
            <div class="form-group">
                <textarea rows="3" cols="3" class="form-control" name="note" id="note"><?php echo e(old('note', $budget->note)); ?></textarea>
            </div>
        </div>
    <?php endif; ?>

    <div class="text-end">
        <button type="submit" class="btn btn-primary transaction-submit-btn"><?php echo e(__('common.btn.submit')); ?><i class="ph-paper-plane-tilt ms-2"></i></button>
    </div>
</form>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/layouts/budgets/budget-form.blade.php ENDPATH**/ ?>