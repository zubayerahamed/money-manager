<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.setup-layout','data' => ['pageTitle' => ''.e(__('setup.page.requirements.title')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('setup-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => ''.e(__('setup.page.requirements.title')).'']); ?>
    <div class="card-body">
        <h6 class="text-center"><?php echo e(__('setup.page.heading.requirements')); ?></h6>

        <div class="list-group">
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $successful): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item d-flex align-items-center">
                    <b><?php echo e($key); ?></b>
                    <?php if($successful): ?>
                        <i class="ph-thumbs-up text-success ms-auto"></i>
                    <?php else: ?>
                        <i class="ph-thumbs-down text-danger ms-auto"></i>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="card-footer">
        <a href="<?php echo e(route('setup.welcome')); ?>" class="btn btn-sm btn-light"><i class="ph-arrow-fat-lines-left me-2"></i> <?php echo e(__('setup.btn.previous')); ?></a>
        <a href="<?php echo e(route('setup.database')); ?>" class="btn btn-sm <?php echo e($success ? 'btn-success' : ' btn-danger disabled'); ?> float-end"><?php echo e(__('setup.btn.next')); ?> <i class="ph-arrow-fat-lines-right ms-2"></i></a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/setup/requirements.blade.php ENDPATH**/ ?>