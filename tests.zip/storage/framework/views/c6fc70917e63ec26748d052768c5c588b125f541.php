<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageTitle' => ''.e(__('budget.page.title')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => ''.e(__('budget.page.title')).'']); ?>
    <!-- Content -->
    <div class="content">
        <div class="row">
            <div class="col-xl-12">
                <input type="hidden" id="sections-reloader" value="<?php echo e(route('budget.sections')); ?>" data-defined-route="<?php echo e($sectionReloadRoute); ?>">

                <!-- Budget Section -->
                <div class="card">

                    <div class="card-header">
                        <div class="text-center col-md-12">
                            <h3 class="mb-0"><?php echo e(__('budget.header.budget')); ?></h3>
                            <h4 class="mb-0">
                                <a href="<?php echo e(route('budget.index', [$month, $year - 1])); ?>"><i class="fas fa-arrow-alt-circle-left"></i></a> <?php echo e($year); ?>

                                <a href="<?php echo e(route('budget.index', [$month, $year + 1])); ?>"><i class="fas fa-arrow-alt-circle-right"></i></a>
                            </h4>
                            <h4 class="mb-0">
                                <a href="<?php echo e(route('budget.index', [$month == 1 ? $month : $month - 1, $year])); ?>"><i class="fas fa-arrow-alt-circle-left"></i></a> <?php echo e($monthText); ?>

                                <a href="<?php echo e(route('budget.index', [$month == 12 ? $month : $month + 1, $year])); ?>"><i class="fas fa-arrow-alt-circle-right"></i></a>
                            </h4>
                        </div>
                    </div>

                    <div class="budgets-accordion">
                        <?php echo $__env->make('layouts.budgets.budgets-accordion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                </div>
                <!-- ./Budget Section -->

            </div>
        </div>
    </div>
    <!-- ./Content -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/budgets.blade.php ENDPATH**/ ?>