<?php if(!$subExpenseTypes->isEmpty()): ?>
    <h6 class="text-center text-muted m-0 mb-1">Sub Expenses</h6>
    <a href="#" class="btn btn-sm btn-primary col-12 mb-2 calculate-amounts">Calculate & Set</a>

    <div class="row mb-3" style="max-height: 397px; overflow-y: auto">

        <?php $__currentLoopData = $subExpenseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $se): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 mb-1">
                <div class="form-floating">
                    <input type="number" class="form-control numeric-only <?php echo e($se->active ? '' : 'is-invalid'); ?> sub-expense-amt" placeholder="Placeholder" name="sub_expense_<?php echo e($se->id); ?>" value="<?php echo e($se->amount); ?>">
                    <label><?php echo e($se->name); ?></label>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <script>
        $(document).ready(function() {
            $('.xub-expenses-wrapper').removeClass('d-none');
            $('.main-trn-form-container').addClass('col-md-8');
            $('.main-trn-form-container').removeClass('col-md-12');

            $('.calculate-amounts').off('click').on('click', function(e){
                e.preventDefault();

                var total = Number(0);
                $('.sub-expense-amt').each(function(i, item){
                    var amt = $(item).val();
                    if(amt == null || amt == '') amt = 0;
                    total += Number(amt);
                });

                $('#amount').val(total);

            })
        })
    </script>
<?php else: ?>
    <script>
        $(document).ready(function() {
            $('.xub-expenses-wrapper').addClass('d-none');
            $('.main-trn-form-container').removeClass('col-md-8');
            $('.main-trn-form-container').addClass('col-md-12');
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/sub-expense-types/sub-expense-list.blade.php ENDPATH**/ ?>