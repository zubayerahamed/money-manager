<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageTitle' => ''.e(__('profile.page.title')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => ''.e(__('profile.page.title')).'']); ?>
    <!-- Content -->
    <div class="content">
        <div class="row">
            <div class="col-xl-12">

                <div class="row">
                    <!-- Profile Photo Section -->
                    <div class="col-lg-4">

                        <div class="card">
                            <div class="sidebar-section-body text-center" style="padding: 20px;">

                                <div class="card-img-actions d-inline-block mb-3">
                                    <img class="img-fluid rounded-circle" src="<?php echo e(auth()->user()->avatar); ?>" width="150" height="150" alt="">
                                    <div class="card-img-actions-overlay card-img rounded-circle">
                                        <input type="file" name="image" class="form-control avatar-image" id="avatar" accept="image/*">
                                        <a href="<?php echo e(route('profile.avatar')); ?>" class="btn btn-outline-white btn-icon rounded-pill avatar-upload" id="avatar-upload">
                                            <i class="ph-pencil"></i>
                                        </a>
                                    </div>
                                </div>

                                <h6 class="mb-0"><?php echo e($user->name); ?></h6>

                            </div>
                        </div>

                    </div>
                    <!-- ./Profile Photo Section -->

                    <!-- Profile Info Section -->
                    <div class="col-lg-8">

                        <!-- Update Profile -->
                        <div class="card">

                            <div class="card-header d-flex align-items-center">
                                <h5 class="mb-0"><?php echo e(__('profile.section1.title')); ?></h5>
                            </div>

                            <div class="card-body border-top">
                                <form action="<?php echo e(route('profile.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="row mb-3">
                                        <label class="form-label" for="name"><?php echo e(__('profile.label.name')); ?></label>
                                        <div class="form-group">
                                            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required>
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label class="form-label" for="currency"><?php echo e(__('profile.label.currency')); ?></label>
                                        <div class="form-group">
                                            <select id="currency" data-placeholder="Select a Currency..." name="currency" id="currency" class="form-control select2" required>
                                                <option>--Select currency--</option>
                                                <?php $__currentLoopData = getAllCurrency(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>" <?php echo e(old('currency', $user->currency) == $key ? 'selected' : ''); ?>><?php echo e($val); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('common.btn.submit')); ?><i class="ph-paper-plane-tilt ms-2"></i></button>
                                    </div>
                                </form>
                            </div>

                        </div>
                        <!-- ./Update Profile -->

                        <!-- Update Password -->
                        <div class="card">

                            <div class="card-header d-flex align-items-center">
                                <h5 class="mb-0"><?php echo e(__('profile.section2.title')); ?></h5>
                            </div>

                            <div class="card-body border-top">
                                <form action="<?php echo e(route('profile.password')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <div class="row mb-3">
                                        <label class="form-label" for="password"><?php echo e(__('profile.label.password')); ?></label>
                                        <div class="form-group">
                                            <input type="password" name="password" id="password" class="form-control" required>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <label class="form-label" for="password_confirmation"><?php echo e(__('profile.label.password_confirmation')); ?></label>
                                        <div class="form-group">
                                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
                                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="text-end">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('common.btn.submit')); ?><i class="ph-paper-plane-tilt ms-2"></i></button>
                                    </div>
                                </form>
                            </div>

                        </div>
                        <!-- ./Update Password -->

                    </div>
                    <!-- ./Profile Info Section -->
                </div>

            </div>
        </div>
    </div>
    <!-- ./Content -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/profile.blade.php ENDPATH**/ ?>