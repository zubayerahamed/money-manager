<div class="card-body">

    <div class="row text-md-start text-center">
        <p><?php echo e(__('budget.text.total-budget')); ?> : <span class="text-success"><?php echo e($totalBudget); ?> <?php echo e(auth()->user()->currency); ?></span></p>
        <p><?php echo e(__('budget.text.total-spent')); ?> : <span class="text-danger"><?php echo e($totalSpent); ?> <?php echo e(auth()->user()->currency); ?></span></p>
        <p><?php echo e(__('budget.text.total-remaining')); ?> : <span class="text-primary"><?php echo e($totalBudget - $totalSpent > 0 ? $totalBudget - $totalSpent : 0); ?> <?php echo e(auth()->user()->currency); ?></span></p>
    </div>

    <?php if($totalBudget != 0 or $totalSpent != 0): ?>
        <?php if($totalBudget - $totalSpent > 0): ?>
            <div class="progress" style="margin-top: 10px;">
                <div class="progress-bar bg-teal" style="width: <?php echo e(round((100 * $totalSpent) / $totalBudget, 2)); ?>%" aria-valuenow="<?php echo e(round((100 * $totalSpent) / $totalBudget, 2)); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e(round((100 * $totalSpent) / $totalBudget, 2)); ?>% complete</div>
            </div>
        <?php else: ?>
            <div class="progress" style="margin-top: 10px;">
                <div class="progress-bar bg-teal bg-danger" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                    Limit exceeded <?php echo e($totalSpent - $totalBudget); ?> <?php echo e(auth()->user()->currency); ?>

                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

</div>

<div class="accordion accordion-flush" id="accordion_flush">
    <?php $__currentLoopData = $expenseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenseType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="accordion-item">

            <h2 class="accordion-header">
                <button class="accordion-button fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush_item<?php echo e($expenseType->id); ?>">
                    <div class="d-flex align-items-center col-sm-12">

                        <div style="width: 70px; text-align: center;">
                            <i class="<?php echo e($expenseType->icon); ?> fa-2x me-3"></i>
                        </div>

                        <div style="flex-grow: 1">
                            <div style="text-transform: uppercase; font-weight: bold;"><?php echo e($expenseType->name); ?></div>
                            <div class="text-muted fs-sm">
                                <?php if($expenseType->budget): ?>
                                    <?php echo e(__('budget.text.limit')); ?> : <span class="text-success"><?php echo e($expenseType->budget); ?> <?php echo e(auth()->user()->currency); ?></span>
                                    <br/>
                                    <?php echo e(__('budget.text.spent')); ?> : <span class="text-danger"><?php echo e($expenseType->spent == null ? 0 : $expenseType->spent); ?> <?php echo e(auth()->user()->currency); ?></span>
                                    
                                    <br/>
                                    <?php if($expenseType->remaining > 0): ?>
                                        <?php echo e(__('budget.text.remaining')); ?> :
                                        <b class="text-success"><?php echo e($expenseType->remaining); ?> <?php echo e(auth()->user()->currency); ?></b>
                                        <div class="progress" style="margin-top: 10px;">
                                            <div class="progress-bar bg-teal" style="width: <?php echo e($expenseType->percent); ?>%" aria-valuenow="<?php echo e($expenseType->percent); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($expenseType->percent); ?>% complete</div>
                                        </div>
                                    <?php elseif($expenseType->remaining == 0 && $expenseType->exced_amount == 0): ?>
                                        <div class="progress" style="margin-top: 10px;">
                                            <div class="progress-bar bg-teal" style="width: <?php echo e($expenseType->percent); ?>%" aria-valuenow="<?php echo e($expenseType->percent); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($expenseType->percent); ?>% complete</div>
                                        </div>
                                    <?php else: ?>
                                        <?php echo e(__('budget.text.remaining')); ?> :
                                        <b class="text-primary">0 <?php echo e(auth()->user()->currency); ?></b>
                                        <div class="progress" style="margin-top: 10px;">
                                            <div class="progress-bar bg-teal bg-danger" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                                                Limit exceeded <?php echo e($expenseType->exced_amount); ?> <?php echo e(auth()->user()->currency); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo e(__('budget.text.spent')); ?> : <span class="text-danger"><?php echo e($expenseType->spent == null ? 0 : $expenseType->spent); ?> <?php echo e(auth()->user()->currency); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                </button>
            </h2>

            <div id="flush_item<?php echo e($expenseType->id); ?>" class="accordion-collapse collapse" data-bs-parent="#accordion_flush">
                <div class="accordion-body">
                    <div class="col-md-12 text-center">

                        <span class="badge border border-teal text-teal rounded-pill m-auto">
                            <?php if($expenseType->budget): ?>
                                <a href="<?php echo e(route('budget.edit', $expenseType->budget_id)); ?>" class="m-2 text-primary transaction-btn" data-title="<?php echo e(__('budget.btn.edit-budget')); ?>" title="<?php echo e(__('budget.btn.edit-budget')); ?>">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <form id="form-id<?php echo e($expenseType->budget_id); ?>"
                                    action="<?php echo e(route('budget.destroy', $expenseType->budget_id)); ?>"
                                    method="POST" style="display: inline-block;">
                                  <?php echo method_field('DELETE'); ?>
                                  <?php echo csrf_field(); ?>
                                  <a href="#" class="delete-btn text-danger m-2"
                                     onclick="deleteData(this)"
                                     data-form-id="<?php echo e('form-id' . $expenseType->budget_id); ?>"
                                     title="<?php echo e(__('budget.btn.delete-budget')); ?>">
                                      <i class="fas fa-trash"></i>
                                  </a>
                              </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('budget.create', [$expenseType->id, $month, $year])); ?>" class="m-2 text-success transaction-btn" data-title="<?php echo e(__('budget.btn.create-budget')); ?>" title="<?php echo e(__('budget.btn.create-budget')); ?>">
                                    <i class="fas fa-calculator"></i>
                                </a>
                            <?php endif; ?>
                        </span>

                    </div>
                </div>
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/budgets/budgets-accordion.blade.php ENDPATH**/ ?>