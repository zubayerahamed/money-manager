<?php $__currentLoopData = $expenseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenseType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordion-item">

        <h2 class="accordion-header">
            <button class="accordion-button fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush_item<?php echo e($expenseType->id); ?>">
                <div class="d-flex align-items-center">

                    <div style="width: 70px; text-align: center;">
                        <i class="<?php echo e($expenseType->icon); ?> fa-2x me-3"></i>
                    </div>

                    <div>
                        <div style="text-transform: uppercase; font-weight: bold;"><?php echo e($expenseType->name); ?></div>
                        <div class="text-muted fs-sm">
                            <span class="d-inline-block bg-primary rounded-pill p-1 me-1"></span> <span><?php echo e($expenseType->totalExpense == null ? 0 : $expenseType->totalExpense); ?> <?php echo e(auth()->user()->currency); ?></span>
                        </div>
                    </div>

                </div>
            </button>
        </h2>

        <div id="flush_item<?php echo e($expenseType->id); ?>" class="accordion-collapse collapse" data-bs-parent="#accordion_flush">
            <div class="accordion-body">
                <div class="col-md-12 text-center">

                    <?php if($expenseType->note != ''): ?>
                        <div class="col-md-12 text-center mb-2">
                            <span class="fw-semibold"><?php echo e($expenseType->note); ?></span>
                        </div>
                    <?php endif; ?>

                    <span class="badge border border-teal text-teal rounded-pill m-auto">
                        <a href="<?php echo e(route('expense-type.edit', $expenseType->id)); ?>" class="m-2 text-primary transaction-btn" title="<?php echo e(__('expense-type.btn.edit-expense-type')); ?>" data-title="<?php echo e(__('expense-type.btn.edit-expense-type')); ?>">
                            <i class="fas fa-edit"></i>
                        </a>

                        <form id="form-id<?php echo e($expenseType->id); ?>"
                              action="<?php echo e(route('expense-type.destroy', $expenseType->id)); ?>"
                              method="POST" style="display: inline-block;">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <a href="#" class="delete-btn text-danger m-2"
                               onclick="deleteData(this)"
                               data-form-id="<?php echo e('form-id' . $expenseType->id); ?>"
                               title="<?php echo e(__('expense-type.btn.delete-expense-type')); ?>">
                                <i class="fas fa-trash"></i>
                            </a>
                        </form>
                    </span>

                </div>
            </div>
        </div>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/layouts/expense-types/expense-types-accordion.blade.php ENDPATH**/ ?>