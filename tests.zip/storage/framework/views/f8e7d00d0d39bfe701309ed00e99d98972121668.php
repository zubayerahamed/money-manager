<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['pageTitle' => ''.e(__('transaction.details.page.title')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => ''.e(__('transaction.details.page.title')).'']); ?>
    <!-- Content -->
    <div class="content">
        <div class="row">

            <!-- Transaction Details -->
            <div class="col-xl-12">
                <input type="hidden" id="sections-reloader" value="<?php echo e(route('tracking.sections')); ?>" data-defined-route="<?php echo e($sectionReloadRoute); ?>">

                <?php if($displayType == 'yearWiseSummary'): ?>
                    <h5 class="text-center">Year wise transactions summary</h5>
                <?php else: ?>
                    <h5 class="text-center"><?php echo e(__('transaction.details.page.title')); ?></h5>
                <?php endif; ?>
               
                <div class="transaction-detail-accordion">
                    <?php if($displayType == 'yearWiseSummary'): ?>
                        <?php echo $__env->make('layouts.transactions.transaction-detail-yearwise-summary-accordion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <?php echo $__env->make('layouts.transactions.transaction-detail-accordion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <!-- ./Transaction Details -->

        </div>
    </div>
    <!-- ./Content -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/th-details.blade.php ENDPATH**/ ?>