<form id="transaction-form" action="<?php echo e(url('/transaction')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="transaction_type" value="<?php echo e($transaction_type); ?>" />

    <div class="row">

        <div class="col sm-6">
            <div class="row mb-3">
                <label class="form-label" for="amount"><?php echo e(__('transaction.label.amount')); ?></label>
                <div class="form-group">
                    <input type="number" name="amount" id="amount" class="form-control" value="0.0" min="0" step="any" required>
                </div>
            </div>
        </div>

        <div class="col sm-6">
            <div class="row mb-3">
                <label class="form-label" for="transaction_charge"><?php echo e(__('transaction.label.charge')); ?></label>
                <div class="form-group">
                    <input type="number" name="transaction_charge" id="transaction_charge" class="form-control" value="0.0" min="0" step="any">
                </div>
            </div>
        </div>

    </div>

    <?php if($transaction_type == 'EXPENSE' || $transaction_type == 'TRANSFER'): ?>
        <div class="row mb-3">
            <label class="form-label" for="from_wallet"><?php echo e(__('transaction.label.from_wallet')); ?></label>
            <div class="input-group">
                <select class="form-control" name="from_wallet" id="from_wallet" required>
                    <option value="">-- Select Wallet --</option>
                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <a href="<?php echo e(route('wallet.create')); ?>" class="btn btn-light transaction-btn" data-title="<?php echo e(__('wallet.btn.create-wallet')); ?>" title="<?php echo e(__('wallet.btn.create-wallet')); ?>" type="button"><i class="fas fa-plus"></i></a>
            </div>
        </div>

        <?php if($transaction_type == 'EXPENSE'): ?>
            <div class="row mb-3">
                <label class="form-label" for="expense_type"><?php echo e(__('transaction.label.expense_type')); ?></label>
                <div class="input-group">
                    <select class="form-control" name="expense_type" id="expense_type" required>
                        <option value="">-- Select Expense Type --</option>
                        <?php $__currentLoopData = $expenseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenseType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($expenseType->id); ?>"><?php echo e($expenseType->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <a href="<?php echo e(route('expense-type.create')); ?>" class="btn btn-light transaction-btn" data-title="<?php echo e(__('expense-type.btn.create-expense-type')); ?>" title="<?php echo e(__('expense-type.btn.create-expense-type')); ?>" type="button"><i class="fas fa-plus"></i></a>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if($transaction_type == 'INCOME' || $transaction_type == 'TRANSFER'): ?>
        <div class="row mb-3">
            <label class="form-label" for="to_wallet"><?php echo e(__('transaction.label.to_wallet')); ?></label>
            <div class="input-group">
                <select class="form-control" name="to_wallet" id="to_wallet" required>
                    <option value="">-- Select Wallet --</option>
                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <a href="<?php echo e(route('wallet.create')); ?>" class="btn btn-light transaction-btn" data-title="<?php echo e(__('wallet.btn.create-wallet')); ?>" title="<?php echo e(__('wallet.btn.create-wallet')); ?>" type="button"><i class="fas fa-plus"></i></a>
            </div>
        </div>

        <?php if($transaction_type == 'INCOME'): ?>
            <div class="row mb-3">
                <label class="form-label" for="income_source"><?php echo e(__('transaction.label.income_source')); ?></label>
                <div class="input-group">
                    <select class="form-control" name="income_source" id="income_source" required>
                        <option value="">-- Select Income Source --</option>
                        <?php $__currentLoopData = $incomeSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incomeSource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($incomeSource->id); ?>"><?php echo e($incomeSource->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <a href="<?php echo e(route('income-source.create')); ?>" class="btn btn-light transaction-btn" data-title="<?php echo e(__('income-source.btn.create-income-source')); ?>" title="<?php echo e(__('income-source.btn.create-income-source')); ?>" type="button"><i class="fas fa-plus"></i></a>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="row">

        <div class="col sm-6">
            <div class="row mb-3">
                <label class="form-label" for="transaction_date"><?php echo e(__('transaction.label.transaction_date')); ?></label>
                <div class="form-group">
                    <input type="date" name="transaction_date" id="transaction_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" max="<?php echo e(date('Y-m-d')); ?>" required>
                </div>
            </div>
        </div>

        <div class="col sm-6">
            <div class="row mb-3">
                <label class="form-label" for="transaction_tile"><?php echo e(__('transaction.label.transaction_time')); ?></label>
                <div class="form-group">
                    <input type="time" name="transaction_time" id="transaction_time" class="form-control" value="<?php echo e(date('H:i')); ?>" required>
                </div>
            </div>
        </div>

    </div>

    <div class="row mb-3">
        <label class="form-label" for="note"><?php echo e(__('transaction.label.note')); ?></label>
        <div class="form-group">
            <textarea rows="3" cols="3" class="form-control" name="note" id="note"></textarea>
        </div>
    </div>

    <div class="text-end">
        <button type="submit" class="btn btn-primary transaction-submit-btn"><?php echo e(__('common.btn.submit')); ?><i class="ph-paper-plane-tilt ms-2"></i></button>
    </div>
</form>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/layouts/transactions/transaction-create-form.blade.php ENDPATH**/ ?>