<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>
        <?php if(isset($pageTitle)): ?>
            MM | <?php echo e($pageTitle); ?>

        <?php else: ?>
            Money Manager
        <?php endif; ?>
    </title>

    <!-- Stylesheets -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/assets/images/favicon-32x32.png')); ?>">

    <!-- Global stylesheets -->
    <link href="<?php echo e(asset('/assets/fonts/phosphor/styles.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/assets/css/bootstrap.css')); ?>" id="stylesheet" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('/assets/css/kit-bootstrap.css')); ?>" id="stylesheet" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/assets/css/kit-components.css')); ?>" id="stylesheet" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/assets/css/kit-layout.css')); ?>" id="stylesheet" rel="stylesheet" type="text/css">
    <!-- ./Stylesheets -->

    <!-- Core JS files -->
    <script src="<?php echo e(asset('/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- /core JS files -->
</head>

<body>
    <!-- Content -->
    <div class="page-content">
        <!-- Main content -->
        <div class="content-wrapper">
            <!-- Inner content -->
            <div class="content-inner">
                <!-- Content area -->
                <div class="content d-flex justify-content-center align-items-center">

                    <?php echo e($slot); ?>


                </div>
                <!-- ./Content area -->
            </div>
            <!-- ./Inner content -->
        </div>
        <!-- ./Main content -->
    </div>
    <!-- ./Content -->
</body>

</html>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/components/login-register-layout.blade.php ENDPATH**/ ?>