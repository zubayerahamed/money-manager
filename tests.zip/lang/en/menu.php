<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Menu Language Lines
    |--------------------------------------------------------------------------
    */

    "home" => "Home",
    "wallet.status" => "Wallet Status",
    "income.status" => "Income Status",
    "expense.status" => "Expense Status",
    "budget" => "Budget - " .  date('M, Y'),
    "day.history" => "Today's History",
    "dreams" => "Dreams",

];
