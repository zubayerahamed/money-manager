<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.setup-layout','data' => ['pageTitle' => ''.e(__('setup.page.database.title')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('setup-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => ''.e(__('setup.page.database.title')).'']); ?>
    <form action="<?php echo e(route('setup.save-database')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="card-body">
            <h6 class="text-center"><?php echo e(__('setup.page.heading.database')); ?></h6>

            <p class="text-center"><?php echo __('setup.page.sub-heading.database'); ?></p>

            <div class="row">

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="db_host" class="form-label"><?php echo e(__('setup.label.db_host')); ?></label>
                        <input type="text" name="db_host" id="db_host" required class="form-control" placeholder="localhost" value="<?php echo e(old('db_host') ?: env('DB_HOST', 'localhost')); ?>">
                        <?php $__errorArgs = ['db_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="db_port" class="form-label"><?php echo e(__('setup.label.db_port')); ?></label>
                        <input type="number" name="db_port" id="db_port" required class="form-control" placeholder="3306" value="<?php echo e(old('db_port') ?: env('DB_PORT', 3306)); ?>">
                        <?php $__errorArgs = ['db_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

            </div>

            <div class="mb-3">
                <label for="db_name" class="form-label"><?php echo e(__('setup.label.db_name')); ?></label>
                <input type="text" name="db_name" id="db_name" required class="form-control" value="<?php echo e(old('db_name') ?: env('DB_DATABASE')); ?>">
                <?php $__errorArgs = ['db_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="db_user" class="form-label"><?php echo e(__('setup.label.db_user')); ?></label>
                <input type="text" name="db_user" id="db_user" required class="form-control" value="<?php echo e(old('db_user') ?: env('DB_USERNAME')); ?>">
                <?php $__errorArgs = ['db_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="db_password" class="form-label"><?php echo e(__('setup.label.db_password')); ?></label>
                <input type="password" name="db_password" id="db_password" class="form-control" value="<?php echo e(old('db_password') ?: env('DB_PASSWORD')); ?>">
                <?php $__errorArgs = ['db_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="form-text text-danger"><i class="ph-x-circle me-1"></i><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php if(session('data_present', false)): ?>
                <div class="mb-3">
                    <div class="form-check">
                        <input type="hidden" name="overwrite_data" value="0">
                        <input type="checkbox" class="form-check-input" id="overwrite_data" checked />
                        <label class="form-check-label text-danger" for="overwrite_data"><?php echo e(__('setup.label.data_present')); ?></label>
                    </div>
                </div>
            <?php endif; ?>

            <p class="small text-muted mt-3 mb-0 text-center"><?php echo e(__('setup.label.special-note')); ?></p>
        </div>

        <div class="card-footer">
            <a href="<?php echo e(route('setup.requirements')); ?>" class="btn btn-sm btn-light"><i class="ph-arrow-fat-lines-left me-2"></i> <?php echo e(__('setup.btn.previous')); ?></a>
            <button type="submit" class="btn btn-success float-end">
                <?php if($errors->any()): ?>
                    <?php echo e(__('setup.btn.try-again')); ?>

                <?php else: ?>
                    <?php echo e(__('setup.btn.configure-db')); ?>

                <?php endif; ?>
            </button>
        </div>

    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/setup/database.blade.php ENDPATH**/ ?>