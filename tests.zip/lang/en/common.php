<?php


/*
|--------------------------------------------------------------------------
| Common Language Lines
|--------------------------------------------------------------------------
*/

return [
    'process.success' => 'Process successfull.',
    'process.error' => 'Something went wrong, please try again later.',

    'btn.submit' => 'Submit',
    'my-profile' => 'My profile',
    'alert.success.prefix' => 'Well done!',
    'alert.error.prefix' => 'Oh snap!',
    'image.cropper.title' => 'Crop & Resize Image',
    'logout' => 'Logout',
];
