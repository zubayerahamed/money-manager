<form id="transaction-form" action="<?php echo e($incomeSource->id == null ? route('income-source.store') : route('income-source.update', $incomeSource->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($incomeSource->id != null): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <i class="<?php echo e($incomeSource->id == null || $incomeSource->icon == null ? 'fab fa-korvue' : $incomeSource->icon); ?> fa-2x" id="replacable-icon" style="padding: 10px; border: 1px solid #000; border-radius: 5px; margin-bottom: 10px;"></i>

    <div class="row mb-3">
        <label class="form-label" for="icon"><?php echo e(__('income-source.label.icon')); ?></label>
        <div class="input-group">
            <input type="text" class="form-control" name="icon" id="icon" value="<?php echo e($incomeSource->id == null || $incomeSource->icon == null ? 'fab fa-korvue' : $incomeSource->icon); ?>" readonly>
            <button class="btn btn-light" type="button" onclick="openIconModal()">Choose</button>
        </div>
    </div>

    <div class="row mb-3">
        <label class="form-label" for="name"><?php echo e(__('income-source.label.name')); ?></label>
        <div class="form-group">
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($incomeSource->name); ?>" required>
        </div>
    </div>

    <div class="row mb-3">
        <label class="form-label" for="note"><?php echo e(__('income-source.label.note')); ?></label>
        <div class="form-group">
            <textarea rows="3" cols="3" class="form-control" name="note" id="note"><?php echo e($incomeSource->note); ?></textarea>
        </div>
    </div>

    <div class="text-end">
        <button type="submit" class="btn btn-primary transaction-submit-btn"><?php echo e(__('common.btn.submit')); ?><i class="ph-paper-plane-tilt ms-2"></i></button>
    </div>
</form>

<?php echo $__env->make('icon-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/layouts/income-sources/income-source-form.blade.php ENDPATH**/ ?>