<div class="col-md-6 float-start text-start">
    <h5 class="mb-0"><?php echo e(__('income-source.header.income')); ?> : <?php echo e($totalIncome == null ? 0 : $totalIncome); ?> <?php echo e(auth()->user()->currency); ?></h5>
</div>

<div class="col-md-6 float-end text-end">
    <a href="<?php echo e(route('income-source.create')); ?>" class="btn btn-success btn-sm transaction-btn" title="<?php echo e(__('income-source.btn.create-income-source')); ?>" data-title="<?php echo e(__('income-source.btn.create-income-source')); ?>">
        <i class="ph-plus"></i>
        <div class="d-none d-md-block ms-1"><?php echo e(__('income-source.btn.create-income-source')); ?></div>
    </a>
</div><?php /**PATH D:\3. Zayaan IT\money-manager\resources\views/layouts/income-sources/income-sources-header.blade.php ENDPATH**/ ?>