<form id="transaction-form" action="<?php echo e($dream->id == null ? route('dream.store') : route('dream.update', $dream->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($dream->id != null): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="row mb-3">
        <label class="form-label" for="name"><?php echo e(__('dream.label.name')); ?></label>
        <div class="form-group">
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($dream->name); ?>" required>
        </div>
    </div>

    <div class="row mb-3">
        <label class="form-label" for="amount_needed"><?php echo e(__('dream.label.amount_needed')); ?></label>
        <div class="form-group">
            <input type="number" name="amount_needed" id="amount_needed" class="form-control" value="<?php echo e($dream->amount_needed == null ? '0.0' : $dream->amount_needed); ?>" min="0" step="any" required>
        </div>
    </div>

    <div class="row mb-3">
        <label class="form-label" for="target_year"><?php echo e(__('dream.label.target_year')); ?></label>
        <div class="form-group">
            <input type="number" name="target_year" id="target_year" class="form-control" min="1900" max="2099" step="1" value="<?php echo e($dream->target_year == null ? date('Y') : $dream->target_year); ?>" required />
        </div>
    </div>

    <div class="row mb-3">
        <label class="form-label" for="wallet_id"><?php echo e(__('dream.label.wallet_id')); ?></label>
        <div class="input-group">
            <select class="form-control" name="wallet_id" id="wallet_id">
                <option value="">-- Select Wallet --</option>
                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($wallet->id); ?>" <?php echo e($dream->wallet_id == $wallet->id ? 'selected' : ''); ?>><?php echo e($wallet->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <a href="<?php echo e(route('wallet.create')); ?>" class="btn btn-light transaction-btn" data-title="<?php echo e(__('wallet.btn.create-wallet')); ?>" title="<?php echo e(__('wallet.btn.create-wallet')); ?>" type="button"><i class="fas fa-plus"></i></a>
        </div>
    </div>

    <div class="row mb-3">
        <label class="form-label" for="note"><?php echo e(__('dream.label.note')); ?></label>
        <div class="form-group">
            <textarea rows="3" cols="3" class="form-control" name="note" id="note"><?php echo e($dream->note); ?></textarea>
        </div>
    </div>

    <div class="text-end">
        <button type="submit" class="btn btn-primary transaction-submit-btn"><?php echo e(__('common.btn.submit')); ?><i class="ph-paper-plane-tilt ms-2"></i></button>
    </div>
</form>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/dreams/dream-form.blade.php ENDPATH**/ ?>