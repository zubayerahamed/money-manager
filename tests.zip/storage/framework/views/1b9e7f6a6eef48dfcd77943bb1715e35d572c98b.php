<?php if(!$expenseType->subExpenseTypes->isEmpty()): ?>
    <div class="col-md-12 mt-2 mb-2">
        <div class="table-responsive">
            <table class="table table-stripped no-wrap" style="text-wrap-mode: nowrap;">
                <tbody>
                    <?php $__currentLoopData = $expenseType->subExpenseTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subExpenseType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 15px; text-align: left;">
                                <a href="<?php echo e(route('sub-expense-type.monthlygrouped', ['sub_expense_type_id' => $subExpenseType->id])); ?>" class="m-2 text-primary transaction-btn" title="View Details" data-title="Expense Details of <?php echo e($subExpenseType->name); ?>">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <form id="form-id-sub<?php echo e($subExpenseType->id); ?>"
                                      action="<?php echo e(route('sub-expense-type.destroy', ['expense_type_id' => $expenseType->id, 'id' => $subExpenseType->id])); ?>"
                                      method="POST" style="display: inline-block;">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <a href="#" class="delete-btn text-danger m-2 text-sm"
                                       onclick="deleteData(this)"
                                       data-form-id="<?php echo e('form-id-sub' . $subExpenseType->id); ?>"
                                       title="Delete sub expense type">
                                        <i class="fas fa-trash text-sm"></i>
                                    </a>
                                </form>
                            </td>
                            <td style="text-align: left; font-weight: bold">
                                <a href="<?php echo e(route('sub-expense-type.edit', ['expense_type_id' => $subExpenseType->expense_type_id, 'id' => $subExpenseType->id])); ?>"
                                   class="transaction-btn text-muted"
                                   title="Edit Sub Expense Type"
                                   data-title="Edit Sub Expense Type">
                                    <span>
                                        <?php echo e($subExpenseType->name); ?>

                                    </span>
                                    <div class="text-muted fs-sm">
                                        <span class="d-inline-block <?php echo e($subExpenseType->active ? 'bg-primary' : 'bg-danger'); ?> rounded-pill p-1 me-1"></span> <span><?php echo e($subExpenseType->totalExpense == null ? 0 : $subExpenseType->totalExpense); ?> <?php echo e(auth()->user()->currency); ?></span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\money-manager\resources\views/layouts/sub-expense-types/sub-expense-types-accordion.blade.php ENDPATH**/ ?>